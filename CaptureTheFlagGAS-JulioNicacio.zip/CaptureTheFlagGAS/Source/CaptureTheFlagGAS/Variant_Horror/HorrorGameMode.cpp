// Copyright Epic Games, Inc. All Rights Reserved.


#include "Variant_Horror/HorrorGameMode.h"

AHorrorGameMode::AHorrorGameMode()
{
	// stub
}
