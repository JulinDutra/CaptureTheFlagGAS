// Copyright Epic Games, Inc. All Rights Reserved.

#include "CaptureTheFlagGAS.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CaptureTheFlagGAS, "CaptureTheFlagGAS" );

DEFINE_LOG_CATEGORY(LogCaptureTheFlagGAS)